# Accueil - French language pack for FHIR R4 v0.1.0

* [**Table of Contents**](toc.md)
* **Accueil**

## Accueil

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/fr/ImplementationGuide/ans.fhir.r4.fr | *Version*:0.1.0 |
| Draft as of 2025-12-22 | *Computable Name*:FHIRLangPackFrench |

# Translation of HL7 FHIR resources to Swedish

This Language Pack may include both HL7 FHIR CodeSystems and DomainResources.

