# Artifacts Summary - French language pack for FHIR R4 v0.1.0

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

## Artifacts Summary

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Terminology: Code Systems 

These define new code systems used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [ActCode](CodeSystem-cs-fr-FR-v3-ActCode.md) | A code specifying the particular kind of Act that the Act-instance represents within its class.**Constraints:**The kind of Act (e.g. physical examination, serum potassium, inpatient encounter, charge financial transaction, etc.) is specified with a code from one of several, typically external, coding systems. The coding system will depend on the class of Act, such as LOINC for observations, etc. Conceptually, the Act.code must be a specialization of the Act.classCode. This is why the structure of ActClass domain should be reflected in the superstructure of the ActCode domain and then individual codes or externally referenced vocabularies subordinated under these domains that reflect the ActClass structure. Act.classCode and Act.code are not modifiers of each other but the Act.code concept should really imply the Act.classCode concept. For a negative example, it is not appropriate to use an Act.code "potassium" together with and Act.classCode for "laboratory observation" to somehow mean "potassium laboratory observation" and then use the same Act.code for "potassium" together with Act.classCode for "medication" to mean "substitution of potassium". This mutually modifying use of Act.code and Act.classCode is not permitted. |
| [ActMood](CodeSystem-cs-fr-FR-v3-ActMood.md) | OpenIssue: In Ballot 2009May, a strong Negative vote was lodged against several of the concept definitions in the vocabulary used for Act.moodCode. The vote was found "Persuasive With Mod", with the understanding that M and M would undertake a detailed review of these concept definitions for a future release of the RIM. |
| [ActPriority](CodeSystem-cs-fr-FR-v3-ActPriority.md) | A set of codes (e.g., for routine, emergency), specifying the urgency under which the Act happened, can happen, is happening, is intended to happen, or is requested/demanded to happen. |
| [ActStatus](CodeSystem-cs-fr-FR-v3-ActStatus.md) | Codes representing the defined possible states of an Act, as defined by the Act class state machine. |
| [AdministrativeGender](CodeSystem-cs-fr-FR-v3-AdministrativeGender.md) | The gender of a person used for adminstrative purposes (as opposed to clinical gender) |
| [AllergyIntoleranceClinicalStatusCodes](CodeSystem-cs-fr-FR-allergyintolerance-clinical.md) | Preferred value set for AllergyIntolerance Clinical Status. |
| [AllergyIntoleranceCriticality](CodeSystem-cs-fr-FR-allergy-intolerance-criticality.md) | Estimate of the potential clinical harm, or seriousness, of a reaction to an identified substance. |
| [ConditionClinicalStatusCodes](CodeSystem-cs-fr-FR-condition-clinical.md) | Preferred value set for Condition Clinical Status. |
| [ConditionVerificationStatus](CodeSystem-cs-fr-FR-condition-ver-status.md) | The verification status to support or decline the clinical status of the condition or diagnosis. |
| [Confidentiality](CodeSystem-cs-fr-FR-v3-Confidentiality.md) | A set of codes specifying the security classification of acts and roles in accordance with the definition for concept domain "Confidentiality". |
| [EmploymentStatus](CodeSystem-cs-fr-FR-v2-0066.md) | HL7-defined code system of concepts which specify an employment status of a person. Used in HL7 Version 2 messaging in the GT1 segment. |
| [MediaType](CodeSystem-cs-fr-FR-v3-mediaType.md) | Internet Assigned Numbers Authority (IANA) Mime Media Types. Identifies the type of the encapsulated data and identifies a method to interpret or render the data. The IANA defined domain of media types is established by the Internet standard RFC 2045 [http://www.ietf.org/rfc/rfc2045.txt] and 2046 [http://www.ietf.org/rfc/rfc2046.txt]. RFC 2046 defines the media type to consist of two parts:1. top level media type, and
1. media subtype However, this HL7 datatypes specification treats the entire media type as one atomic code symbol in the form defined by IANA, i.e., top level type followed by a slash "/" followed by media subtype. Currently defined media types are registered in a database [http://www.iana.org/assignments/media-types/index.html] maintained by IANA. Currently several hundred different MIME media types are defined, with the list growing rapidly. In general, all those types defined by the IANA MAY be used.
 |
| [ObservationInterpretation](CodeSystem-cs-fr-FR-v3-ObservationInterpretation.md) | One or more codes providing a rough qualitative interpretation of the observation, such as "normal" / "abnormal", "low" / "high", "better" / "worse", "resistant" / "susceptible", "expected" / "not expected". The value set is intended to be for ANY use where coded representation of an interpretation is needed. |
| [ObservationMethod](CodeSystem-cs-fr-FR-v3-ObservationMethod.md) | A code that provides additional detail about the means or technique used to ascertain the observation.**Examples:**Blood pressure measurement method: arterial puncture vs. sphygmomanometer (Riva-Rocci), sitting vs. supine position, etc.**OpenIssue:**Description copied from Concept Domain of same name. Must be verified. Note that the Domain has a full discussion about use of the attribute and constraining that is not appropriate for the code system description. Needs to be improved. |
| [ObservationValue](CodeSystem-cs-fr-FR-v3-ObservationValue.md) | This code system covers all concepts of HL7-defined values for the Observation value element, when it has a coded datatype. |
| [OrderableDrugForm](CodeSystem-cs-fr-FR-v3-orderableDrugForm.md) | **OpenIssue:**Missing description. |
| [ParticipationFunction](CodeSystem-cs-fr-FR-v3-ParticipationFunction.md) | This code is used to specify the exact function an actor had in a service in all necessary detail. This domain may include local extensions (CWE). |
| [ParticipationType](CodeSystem-cs-fr-FR-v3-ParticipationType.md) | A code specifying the meaning and purpose of every Participation instance. Each of its values implies specific constraints on the Roles undertaking the participation. |
| [RoleClass](CodeSystem-cs-fr-FR-v3-RoleClass.md) | Codes for the Role class hierarchy. The values in this hierarchy, represent a Role which is an association or relationship between two entities - the entity that plays the role and the entity that scopes the role. Roles names are derived from the name of the playing entity in that role. The role hierarchy stems from three core concepts, or abstract domains:* **RoleClassOntological** is an abstract domain that collects roles in which the playing entity is defined or specified by the scoping entity. 
* **RoleClassPartitive** collects roles in which the playing entity is in some sense a "part" of the scoping entity. 
* **RoleClassAssociative** collects all of the remaining forms of association between the playing entity and the scoping entity. This set of roles is further partitioned between: 
* **RoleClassPassive** which are roles in which the playing entity is used, known, treated, handled, built, or destroyed, etc. under the auspices of the scoping entity. The playing entity is passive in these roles in that the role exists without an agreement from the playing entity. 
* **RoleClassMutualRelationship** which are relationships based on mutual behavior of the two entities. The basis of these relationship may be formal agreements or they may be **de facto** behavior. Thus, this sub-domain is further divided into: 
* **RoleClassRelationshipFormal** in which the relationship is formally defined, frequently by a contract or agreement. 
* **Personal relationship** which inks two people in a personal relationship. The hierarchy discussed above is represented In the current vocabulary tables as a set of abstract domains, with the exception of the "Personal relationship" which is a leaf concept. **OpenIssue:** Description copied from Concept Domain of same name. Must be verified.
 
 
 |
| [RoleCode](CodeSystem-cs-fr-FR-v3-RoleCode.md) | A set of codes further specifying the kind of Role; specific classification codes for further qualifying RoleClass codes. |
| [SpecimenType](CodeSystem-cs-fr-FR-v2-0487.md) | HL7-defined code system of concepts that describe the precise nature of an entity that may be used as the source material for an observation. This is one of two code systems that are used instead of table 0070 (code system 2.16.840.1.113883.18.28) which conflated specimen types and specimen collection methods. Used in HL7 Version 2.x messaging in the SPM segment. |
| [SubstanceAdminSubstitution](CodeSystem-cs-fr-FR-v3-substanceAdminSubstitution.md) | Identifies what sort of change is permitted or has occurred between the therapy that was ordered and the therapy that was/will be provided. |
| [TimingEvent](CodeSystem-cs-fr-FR-v3-TimingEvent.md) | **** MISSING DESCRIPTION **** |

