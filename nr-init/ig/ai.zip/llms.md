# ans.fhir.r4.fr#0.1.0: French language pack for FHIR R4

## Pages

* [Accueil](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [AllergyIntoleranceCriticality](CodeSystem-cs-fr-allergy-intolerance-criticality.md)
* [AllergyIntolerance Clinical Status Codes](CodeSystem-cs-fr-allergyintolerance-clinical.md)
* [Condition Clinical Status Codes](CodeSystem-cs-fr-condition-clinical.md)
* [ConditionVerificationStatus](CodeSystem-cs-fr-condition-ver-status.md)
* [employmentStatus](CodeSystem-cs-fr-v2-0066.md)
* [specimenType](CodeSystem-cs-fr-v2-0487.md)
* [ActCode](CodeSystem-cs-fr-v3-ActCode.md)
* [ActMood](CodeSystem-cs-fr-v3-ActMood.md)
* [ActPriority](CodeSystem-cs-fr-v3-ActPriority.md)
* [ActStatus](CodeSystem-cs-fr-v3-ActStatus.md)
* [AdministrativeGender](CodeSystem-cs-fr-v3-AdministrativeGender.md)
* [Confidentiality](CodeSystem-cs-fr-v3-Confidentiality.md)
* [ObservationInterpretation](CodeSystem-cs-fr-v3-ObservationInterpretation.md)
* [ObservationMethod](CodeSystem-cs-fr-v3-ObservationMethod.md)
* [ObservationValue](CodeSystem-cs-fr-v3-ObservationValue.md)
* [ParticipationFunction](CodeSystem-cs-fr-v3-ParticipationFunction.md)
* [ParticipationType](CodeSystem-cs-fr-v3-ParticipationType.md)
* [RoleClass](CodeSystem-cs-fr-v3-RoleClass.md)
* [RoleCode](CodeSystem-cs-fr-v3-RoleCode.md)
* [TimingEvent](CodeSystem-cs-fr-v3-TimingEvent.md)
* [Media Type](CodeSystem-cs-fr-v3-mediaType.md)
* [Orderable Drug Form](CodeSystem-cs-fr-v3-orderableDrugForm.md)
* [Substance Admin Substitution](CodeSystem-cs-fr-v3-substanceAdminSubstitution.md)

### ValueSets

* [AdministrativeGender](ValueSet-jdv-hl7-v3-AdministrativeGender-cisis.md)

### ImplementationGuides

* [French language pack for FHIR R4](index.md)
