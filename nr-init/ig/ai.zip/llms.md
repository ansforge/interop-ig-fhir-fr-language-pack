# ans.fhir.r4.fr#0.1.0: French language pack for FHIR R4

## Pages

* [Accueil](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [AddressType](CodeSystem-cs-fr-FR-address-type.md)
* [AddressUse](CodeSystem-cs-fr-FR-address-use.md)
* [AdministrativeGender](CodeSystem-cs-fr-FR-administrative-gender.md)
* [ConditionVerificationStatus](CodeSystem-cs-fr-FR-condition-ver-status.md)
* [ContactPointSystem](CodeSystem-cs-fr-FR-contact-point-system.md)
* [ContactPointUse](CodeSystem-cs-fr-FR-contact-point-use.md)
* [Contact entity type](CodeSystem-cs-fr-FR-contactentity-type.md)
* [DaysOfWeek](CodeSystem-cs-fr-FR-days-of-week.md)
* [IdentifierUse](CodeSystem-cs-fr-FR-identifier-use.md)
* [LinkType](CodeSystem-cs-fr-FR-link-type.md)
* [NameUse](CodeSystem-cs-fr-FR-name-use.md)
* [contactRole2](CodeSystem-cs-fr-FR-v2-0131.md)
* [identifierType](CodeSystem-cs-fr-FR-v2-0203.md)
* [EntityNamePartQualifierR2](CodeSystem-cs-fr-FR-v3-EntityNamePartQualifierR2.md)
* [MaritalStatus](CodeSystem-cs-fr-FR-v3-MaritalStatus.md)
* [NullFlavor](CodeSystem-cs-fr-FR-v3-NullFlavor.md)

### ImplementationGuides

* [French language pack for FHIR R4](index.md)
