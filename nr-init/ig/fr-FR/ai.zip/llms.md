# ans.fhir.r4.fr#0.1.0: French language pack for FHIR R4(fr-FR)

## Pages

* [Accueil](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [AdministrativeGender](CodeSystem-cs-fr-FR-v3-AdministrativeGender.md)

### ValueSets

* [AdministrativeGender](ValueSet-jdv-hl7-v3-AdministrativeGender-cisis.md)

### ImplementationGuides

* [French language pack for FHIR R4](ImplementationGuide-ans.fhir.r4.fr.md)
