# ans.fhir.r4.fr#0.1.0: French language pack for FHIR R4(fr)

## Pages

* [Accueil](index.md)
* [Résumé des artefacts](artifacts.md)

## Resources

### CodeSystems

* [employmentStatus](CodeSystem-cs-fr-v2-0066.md)
* [AdministrativeGender](CodeSystem-cs-fr-v3-AdministrativeGender.md)
* [Orderable Drug Form](CodeSystem-cs-fr-v3-orderableDrugForm.md)

### ValueSets

* [AdministrativeGender](ValueSet-jdv-hl7-v3-AdministrativeGender-cisis.md)

### ImplementationGuides

* [French language pack for FHIR R4](ImplementationGuide-ans.fhir.r4.fr.md)
